/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*; 
/**
 *
 * @author Andrei
 */
public class TrainStation {
    // fields
    public int station_id;
    public String station_name;
    public int train_line_id;
    public String station_location;
    public String founding_date;
    public int is_pwd_friendly;
    public String converted; 
    
    //list
    public ArrayList<Integer> list_station_id = new ArrayList<>();
    public ArrayList<String> list_station_name = new ArrayList<>();
    public ArrayList<Integer> list_train_line_id = new ArrayList<>();
    public ArrayList<String> list_station_location = new ArrayList<>();
    public ArrayList<String> list_founding_date = new ArrayList<>();
    public ArrayList<Integer> list_is_pwd_friendly = new ArrayList<>();
    
    public ArrayList<String> list_converted = new ArrayList<>(); 
    
    // empty constructor
    public TrainStation() {
    
    }
    
    public int update_TrainStation() {
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("UPDATE train_stations SET station_name = ? WHERE station_id = ?");
            psmt.setString(1, station_name); 
            psmt.setInt(2, station_id); 
            
            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    
    }
    
    public int delete_TrainStation() {
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("DELETE FROM train_stations WHERE station_id = ?");
            psmt.setInt(1, station_id); 
            
            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    public int add_TrainStations() {
       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(station_id) + 1 as newStationID FROM train_stations");
            ResultSet rst = psmt.executeQuery();
            
            while(rst.next()) {
               station_id = rst.getInt("newStationID"); 
            }
            
            // station_id, station_name, train_line_id, station_location, founding_date, is_pwd_friendly
            
            psmt = conn.prepareStatement("INSERT INTO train_stations(station_id, station_name, train_line_id, station_location, founding_date, is_pwd_friendly) VALUES(?, ?, ?, ?, ?, ?)");
            psmt.setInt(1, station_id); 
            psmt.setString(2, station_name); 
            psmt.setInt(3, train_line_id); 
            psmt.setString(4, station_location); 
            psmt.setString(5, founding_date);
            psmt.setInt(6, is_pwd_friendly);
            
            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    
    }
    
    public int get_TrainStations() {
                       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT station_id, station_name, train_line_id, station_location, founding_date, is_pwd_friendly FROM train_stations");
            ResultSet rst = psmt.executeQuery();
            
            // Clear lists before adding values
            list_station_id.clear();
            list_station_name.clear();
            list_train_line_id.clear();
            list_station_location.clear();
            list_founding_date.clear();
            list_is_pwd_friendly.clear();
            list_converted.clear(); 

            while (rst.next()) {
                // Retrieve each field from the ResultSet
                station_id = rst.getInt("station_id");
                station_name = rst.getString("station_name");
                train_line_id = rst.getInt("train_line_id");
                station_location = rst.getString("station_location");
                founding_date = rst.getString("founding_date");
                is_pwd_friendly = rst.getInt("is_pwd_friendly");
                
                if (is_pwd_friendly == 1) {
                    converted = "Yes"; 
                } else {
                    converted = "No"; 
                }

                // Add values to the corresponding ArrayLists
                list_station_id.add(station_id);
                list_station_name.add(station_name);
                list_train_line_id.add(train_line_id);
                list_station_location.add(station_location);
                list_founding_date.add(founding_date);
                list_is_pwd_friendly.add(is_pwd_friendly);
                list_converted.add(converted); 
            }
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0; 
    }
}
    

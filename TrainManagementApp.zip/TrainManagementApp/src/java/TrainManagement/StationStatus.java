/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*; 

/**
 *
 * @author Andrei
 */
public class StationStatus {
    // fields 
    public int station_status_id;
    public int station_id;
    public String status_rep;
    public String start_date;
    public String end_date;
    
    public String line_name; 
    public String station_name; 
    
    // list
    public ArrayList<Integer> list_station_status_id = new ArrayList<>();
    public ArrayList<Integer> list_station_id = new ArrayList<>();
    public ArrayList<String> list_status_rep = new ArrayList<>();
    public ArrayList<String> list_start_date = new ArrayList<>();
    public ArrayList<String> list_end_date = new ArrayList<>();
    
    public ArrayList<String> list_line_name = new ArrayList<>();
    public ArrayList<String> list_station_name = new ArrayList<>();
    
    // empty constructor
    public StationStatus() {
        
    }
    
    // fix
    public int update_StationStatus() {
       int newStatusID = -1; 
       int curr_station_id = -1; 
        
    try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        // Connect to the database
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtrains", "root", "Dlsuid12343080#");
        System.out.println("Connection successful!");
        
        // Get the new station status ID
        PreparedStatement psmt1 = conn.prepareStatement("SELECT MAX(station_status_id) + 1 AS newStatusID FROM station_status_history");
        ResultSet rst1 = psmt1.executeQuery(); 
        
        if (rst1.next()) {
            newStatusID = rst1.getInt("newStatusID");
        }
        rst1.close();
        psmt1.close();

        // Get the previous station ID
        PreparedStatement psmt2 = conn.prepareStatement("SELECT station_id FROM station_status_history WHERE station_status_id = ?");
        psmt2.setInt(1, station_status_id); 
        ResultSet rst2 = psmt2.executeQuery(); 
        
        if (rst2.next()) {
            curr_station_id = rst2.getInt("station_id");
        }
        rst2.close();
        psmt2.close();

        // Update the end_date for the current status
        PreparedStatement psmt3 = conn.prepareStatement("UPDATE station_status_history SET end_date = ? WHERE station_status_id = ? AND end_date IS NULL");
        psmt3.setString(1, end_date); 
        psmt3.setInt(2, station_status_id);
        psmt3.executeUpdate();
        psmt3.close();

        // Insert the new status
        PreparedStatement psmt4 = conn.prepareStatement("INSERT INTO station_status_history(station_status_id, station_id, status_rep, start_date) VALUES(?, ?, ?, ?)");
        psmt4.setInt(1, newStatusID);
        psmt4.setInt(2, curr_station_id);
        psmt4.setString(3, status_rep); 
        psmt4.setString(4, start_date); 
        psmt4.executeUpdate();
        psmt4.close();

        // Close connection
        conn.close();
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0; 
    }
    
    public int delete_StationStatus() {
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtrains", "root", "Dlsuid12343080#");
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("DELETE FROM station_status_history WHERE station_status_id = ?"); 

            psmt.setInt(1, station_status_id); 

            psmt.executeUpdate(); 
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0; 
    }
    
    public int add_StationStatus() {
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtrains", "root", "Dlsuid12343080#");
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(station_status_id) + 1 AS newStatusID FROM station_status_history"); 
            ResultSet rst = psmt.executeQuery();


            while (rst.next()) {
                station_status_id = rst.getInt("newStatusID");
            }
            
            psmt = conn.prepareStatement("INSERT INTO station_status_history(station_status_id, station_id, status_rep, start_date, end_date) VALUES(?, ?, ?, ?, ?)"); 
            psmt.setInt(1, station_status_id); 
            psmt.setInt(2, station_id);
            psmt.setString(3, status_rep);
            psmt.setString(4, start_date); 
            psmt.setString(5, end_date);
            
            psmt.executeUpdate(); 
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0; 
    }
    
    public void get_StationStatus() {
                       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtrains", "root", "Dlsuid12343080#");
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT std.station_status_id, tl.line_name, ts.station_name, std.station_id, std.status_rep, std.start_date, std.end_date FROM station_status_history std JOIN train_stations ts ON std.station_id = ts.station_id JOIN train_lines tl ON ts.train_line_id = tl.train_line_id"); 
            ResultSet rst = psmt.executeQuery();
            
            // Clear lists before adding values
            list_station_status_id.clear();
            list_station_name.clear();   
            list_line_name.clear();      
            list_status_rep.clear();
            list_start_date.clear();
            list_end_date.clear();
            list_station_id.clear(); 

            while (rst.next()) {
                // Retrieve each field from the ResultSet
                station_status_id = rst.getInt("std.station_status_id");
                line_name = rst.getString("tl.line_name");
                station_name = rst.getString("ts.station_name");
                station_id = rst.getInt("std.station_id");
                status_rep = rst.getString("std.status_rep");
                start_date = rst.getString("std.start_date");
                end_date = rst.getString("std.end_date");

                // Add values to the corresponding ArrayLists
                list_station_status_id.add(station_status_id);
                list_line_name.add(line_name);      
                list_station_name.add(station_name); 
                list_station_id.add(station_id); 
                list_status_rep.add(status_rep);
                list_start_date.add(start_date);
                list_end_date.add(end_date);
            }
            
            psmt.close();
            conn.close(); // close connection
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    
    }
}

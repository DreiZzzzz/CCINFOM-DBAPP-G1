/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*; 
/**
 *
 * @author Andrei
 */
public class TrainDriverLog {
    // fields 
    public int log_id ;
    public int driver_id;
    public int train_id;
    public String start_date;
    public String end_date;
    
    public String first_name; 
    public String last_name; 
    
    // list
    public ArrayList<Integer> list_log_id = new ArrayList<>();
    public ArrayList<Integer> list_driver_id = new ArrayList<>();
    public ArrayList<Integer> list_train_id = new ArrayList<>();
    public ArrayList<String> list_start_date = new ArrayList<>();
    public ArrayList<String> list_end_date = new ArrayList<>();
    
    public ArrayList<String> list_driver_name = new ArrayList<>();

    
    // empty constructor 
    public TrainDriverLog() {
    
    }
    
    public void get_trainDriverLog() {
                       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbtrains", "root", "Dlsuid12343080#");
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT tdl.log_id, tdl.driver_id, d.first_name, d.last_name, tdl.train_id, tdl.start_date, tdl.end_date FROM train_driver_log tdl JOIN drivers d ON tdl.driver_id = d.driver_id");
            ResultSet rst = psmt.executeQuery();
            
        // Clear lists before adding values
        list_log_id.clear();
        list_driver_id.clear();
        list_driver_name.clear(); 
        list_train_id.clear();
        list_start_date.clear();
        list_end_date.clear();

        while (rst.next()) {
            // Retrieve each field from the ResultSet
            log_id = rst.getInt("tdl.log_id");
            driver_id = rst.getInt("tdl.driver_id");
            first_name = rst.getString("d.first_name");
            last_name = rst.getString("d.last_name"); 
            train_id = rst.getInt("tdl.train_id");
            start_date = rst.getString("tdl.start_date");
            end_date = rst.getString("tdl.end_date");

            // Add values to the corresponding ArrayLists
            list_log_id.add(log_id);
            list_driver_id.add(driver_id);
            list_driver_name.add(first_name + " " + last_name);
            list_train_id.add(train_id);
            list_start_date.add(start_date);
            list_end_date.add(end_date);
        }
            
            psmt.close();
            conn.close(); // close connection
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }
    
}
    


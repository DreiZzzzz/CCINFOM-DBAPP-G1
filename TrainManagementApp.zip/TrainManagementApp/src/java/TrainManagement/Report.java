/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*; 

public class Report {
    // fields
    public int station_status_id;
    public String line_name; 
    public String station_name; 
    public String status_rep; 
    public String start_date; 
    public String end_date;
    public int duration; 
    
    public int train_status_id; 
    public int train_id; 
    
    // lists
    public ArrayList<Integer> list_station_status_id = new ArrayList<>();
    public ArrayList<String> list_line_name = new ArrayList<>();
    public ArrayList<String> list_station_name = new ArrayList<>();
    public ArrayList<String> list_status_rep = new ArrayList<>();
    public ArrayList<String> list_start_date = new ArrayList<>();
    public ArrayList<String> list_end_date = new ArrayList<>();
    public ArrayList<Integer> list_duration = new ArrayList<>();
    
    public ArrayList<Integer> list_train_status_id = new ArrayList<>();
    public ArrayList<Integer> list_train_id = new ArrayList<>(); 
    
    // empty constructor 
    public Report() {
    
    }
    
    public int get_TrainReport() {
       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
         PreparedStatement psmt = conn.prepareStatement("SELECT tsl.train_status_id, " +
                                                       "tl.line_name, " +
                                                       "t.train_id, " +
                                                       "tsl.status_rep, " +
                                                       "tsl.start_date, " +
                                                       "tsl.end_date, " +
                                                       "DATEDIFF(tsl.end_date, tsl.start_date) AS duration " +
                                                       "FROM train_status_log tsl " +
                                                       "JOIN trains t ON tsl.train_id = t.train_id " +
                                                       "JOIN train_lines tl ON t.train_line_id = tl.train_line_id " +
                                                       "WHERE tsl.status_rep = 'Incident Report' " +
                                                       "OR tsl.status_rep = 'Under Maintenance'"); 
            ResultSet rst = psmt.executeQuery();
            
            // clear list before adding values
            list_train_status_id.clear();
            list_line_name.clear();
            list_train_id.clear();
            list_status_rep.clear();
            list_start_date.clear();
            list_end_date.clear();
            list_duration.clear();
            
            while (rst.next()) {
                // Retrieve values from the ResultSet
                train_status_id = rst.getInt("tsl.train_status_id");
                line_name = rst.getString("tl.line_name");
                train_id = rst.getInt("t.train_id");
                status_rep = rst.getString("tsl.status_rep");
                start_date = rst.getString("tsl.start_date");
                end_date = rst.getString("tsl.end_date");
                duration = rst.getInt("duration");

                // Add values to the corresponding ArrayLists
                list_train_status_id.add(train_status_id);
                list_line_name.add(line_name);
                list_train_id.add(train_id);
                list_status_rep.add(status_rep);
                list_start_date.add(start_date);
                list_end_date.add(end_date);
                list_duration.add(duration);
            }
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0;
    }
    
    
    public int get_StationReport() {
       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT sh.station_status_id, \n" +
                                                            "       tl.line_name, \n" +
                                                            "       ts.station_name, \n" +
                                                            "       sh.status_rep, \n" +
                                                            "       sh.start_date, \n" +
                                                            "       sh.end_date, \n" +
                                                            "       DATEDIFF(sh.end_date,  sh.start_date) AS duration\n" +
                                                            "       FROM station_status_history sh\n" +
                                                            "       JOIN train_stations ts ON sh.station_id = ts.station_id	\n" +
                                                            "       JOIN train_lines tl ON ts.train_line_id = tl.train_line_id\n" +
                                                            "       WHERE sh.status_rep = 'Incident Report' \n" +
                                                            "       OR sh.status_rep = 'Under Maintenance'"); 
            ResultSet rst = psmt.executeQuery();
            
            // Clear all ArrayLists before populating them
            list_station_status_id.clear();
            list_line_name.clear();
            list_station_name.clear();
            list_status_rep.clear();
            list_start_date.clear();
            list_end_date.clear();
            list_duration.clear();
            

            while (rst.next()) {
                // Assign values from the ResultSet to variables
                station_status_id = rst.getInt("station_status_id");
                line_name = rst.getString("line_name");
                station_name = rst.getString("station_name");
                status_rep = rst.getString("status_rep");
                start_date = rst.getString("start_date");
                end_date = rst.getString("end_date");
                duration = rst.getInt("duration");

                // Add values to the corresponding ArrayLists
                list_station_status_id.add(station_status_id);
                list_line_name.add(line_name);
                list_station_name.add(station_name);
                list_status_rep.add(status_rep);
                list_start_date.add(start_date);
                list_end_date.add(end_date);
                list_duration.add(duration);
            }
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
       
       return 0;
    }
    
    public int TrainReport() {
        return 0; 
    }
}

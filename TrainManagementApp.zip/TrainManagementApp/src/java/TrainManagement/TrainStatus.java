package TrainManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*; 


public class TrainStatus {
    // fields
    public int train_status_id;
    public int train_id;
    public String status_rep; 
    public String start_date;
    public String end_date; 
    
    // list 
    public ArrayList<Integer> list_train_status_id = new ArrayList<>();
    public ArrayList<Integer> list_train_id = new ArrayList<>();
    public ArrayList<String> list_status_rep = new ArrayList<>();
    public ArrayList<String> list_start_date = new ArrayList<>();
    public ArrayList<String> list_end_date = new ArrayList<>();
    
    // empty constructor
    public TrainStatus() {
    
    }
    
    public int add_TrainStatus() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(train_status_id) + 1 AS newStatusID FROM train_status_log");
            ResultSet rst = psmt.executeQuery(); 
            
            while (rst.next()) {
                train_status_id = rst.getInt("newStatusID"); 
            }
            
            psmt = conn.prepareStatement("INSERT INTO train_status_log(train_status_id, train_id, status_rep, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
            psmt.setInt(1, train_status_id);
            psmt.setInt(2, train_id);
            psmt.setString(3, status_rep);
            psmt.setString(4, start_date);
            psmt.setString(5, end_date);

            psmt.executeUpdate(); 

            psmt.close();
            conn.close(); // close connection
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0; 
    }
    
    public int delete_TrainStatus() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("DELETE FROM train_status_log WHERE train_status_id = ?");
            psmt.setInt(1, train_status_id); 
            
            psmt.executeUpdate(); 

            psmt.close();
            conn.close(); // close connection
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0; 
    }
    
    public int view_TrainStatus() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT train_status_id, train_id, status_rep, start_date, end_date FROM train_status_log");
            ResultSet rst = psmt.executeQuery(); 
            
            // Clear lists before adding values
            list_train_status_id.clear();
            list_train_id.clear();
            list_status_rep.clear();
            list_start_date.clear();
            list_end_date.clear();

            while (rst.next()) {
                // Retrieve each field from the result set
                train_status_id = rst.getInt("train_status_id");
                train_id = rst.getInt("train_id");
                status_rep = rst.getString("status_rep");
                start_date = rst.getString("start_date");
                end_date = rst.getString("end_date");

                // Add values to the respective lists
                list_train_status_id.add(train_status_id);
                list_train_id.add(train_id);
                list_status_rep.add(status_rep);
                list_start_date.add(start_date);
                list_end_date.add(end_date);
            }

            psmt.close();
            conn.close(); // close connection
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0;
    }
    
    public int update_TrainStatus() {
            int newStatusID = -1; 
            
            try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Get the new train status id
            PreparedStatement psmt1 = conn.prepareStatement("SELECT MAX(train_status_id) + 1 AS newStatusID FROM train_status_log");
            ResultSet rst1 = psmt1.executeQuery(); 
            
            while (rst1.next()) {
                newStatusID = rst1.getInt("newStatusID"); 
            }
            rst1.close();
            psmt1.close();
            
            
            PreparedStatement psmt2 = conn.prepareStatement("SELECT train_id FROM train_status_log WHERE train_status_id = ?");
            psmt2.setInt(1, train_status_id); 
            ResultSet rst2 = psmt2.executeQuery(); 
            
            while (rst2.next()) {
                train_id = rst2.getInt("train_id");
            }
            rst2.close();
            psmt2.close();
            
            // update the end date of the previous status id of the train
            PreparedStatement psmt3 = conn.prepareStatement("UPDATE train_status_log SET end_date = ? WHERE train_status_id = ? AND end_date IS NULL");
            psmt3.setString(1, end_date); 
            psmt3.setInt(2, train_status_id);
            psmt3.executeUpdate();
            psmt3.close();
            
            // Insert the new status
            PreparedStatement psmt4 = conn.prepareStatement("INSERT INTO train_status_log(train_status_id, train_id, status_rep, start_date) VALUES(?, ?, ?, ?)");
            psmt4.setInt(1, newStatusID);
            psmt4.setInt(2, train_id);
            psmt4.setString(3, status_rep); 
            psmt4.setString(4, start_date); 
            psmt4.executeUpdate();
            psmt4.close();
            
            conn.close(); // close connection
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0; 
    }

}

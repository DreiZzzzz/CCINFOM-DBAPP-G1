/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Andrei
 */
public class MySql {
    
    public static String localUrl = "jdbc:mysql://localhost:3306/dbtrains"; 
    public static String username = "root";
    public static String password = "Hyperion";
}

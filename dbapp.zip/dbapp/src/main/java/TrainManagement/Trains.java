/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;


import java.util.*; 
import java.sql.*; 

public class Trains {
    // fields
    public int train_id; 
    public int train_line_id; 
    public String train_generation;
    public int cart_total; 
    public int maximum_capacity; 
    public String date_acquired; 
    public String date_retired; 
    
    // list 
    public ArrayList<Integer> list_train_id = new ArrayList<>();
    public ArrayList<Integer> list_train_line_id = new ArrayList<>();
    public ArrayList<String> list_train_generation = new ArrayList<>();
    public ArrayList<Integer> list_cart_total = new ArrayList<>();
    public ArrayList<Integer> list_maximum_capacity = new ArrayList<>();
    public ArrayList<String> list_date_acquired = new ArrayList<>();
    public ArrayList<String> list_date_retired = new ArrayList<>();
    
    // empty constructor 
    public Trains() {
    
    }
    
    // continue
    public int delete_train() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("DELETE FROM trains WHERE train_id = ?");
            psmt.setInt(1, train_id);

            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    public int update_trainRetirement() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("UPDATE trains SET date_retired = ? WHERE train_id = ?");
            psmt.setString(1, date_retired); 
            psmt.setInt(2, train_id); 
            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    public int add_Trains() {
       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(train_id) + 1 as newTrainID FROM trains");
            ResultSet rst = psmt.executeQuery();
            
            while(rst.next()) {
               train_id = rst.getInt("newTrainID"); 
            }
            
            
            psmt = conn.prepareStatement("INSERT INTO trains(train_id,train_line_id, train_generation, cart_total, maximum_capacity, date_acquired) VALUES(?, ?, ?, ?, ?, ?)");
            psmt.setInt(1, train_id); 
            psmt.setInt(2, train_line_id);
            psmt.setString(3, train_generation);
            psmt.setInt(4, cart_total);
            psmt.setInt(5, maximum_capacity);
            psmt.setString(6, date_acquired);
            
            psmt.executeUpdate();

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    public int get_TrainRecords() { 
       
       try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            // Use the connection (e.g., create a statement, execute queries, etc.)
            
            PreparedStatement psmt = conn.prepareStatement("SELECT train_id, train_line_id, train_generation, cart_total, maximum_capacity, date_acquired, date_retired FROM trains");
            ResultSet rst = psmt.executeQuery();
            
            list_train_id.clear();
            list_train_line_id.clear();
            list_train_generation.clear();
            list_cart_total.clear();
            list_maximum_capacity.clear();
            list_date_acquired.clear();
            list_date_retired.clear();
            
            while(rst.next()) {
                train_id = rst.getInt("train_id");
                train_line_id = rst.getInt("train_line_id");
                train_generation = rst.getString("train_generation");
                cart_total = rst.getInt("cart_total");
                maximum_capacity = rst.getInt("maximum_capacity");
                date_acquired = rst.getString("date_acquired");
                date_retired = rst.getString("date_retired");

                list_train_id.add(train_id);
                list_train_line_id.add(train_line_id);
                list_train_generation.add(train_generation);
                list_cart_total.add(cart_total);
                list_maximum_capacity.add(maximum_capacity);
                list_date_acquired.add(date_acquired);
                list_date_retired.add(date_retired);
            }
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    
    
    
}

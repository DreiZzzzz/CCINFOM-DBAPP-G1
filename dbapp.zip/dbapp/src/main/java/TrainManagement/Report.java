/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Andrei
 */
public class Report {
    
    public ArrayList listDriverId = new ArrayList<>();
    public ArrayList fullName = new ArrayList<>();
    public ArrayList trainId = new ArrayList<>();
    public ArrayList daysEmployed =  new ArrayList<>();

    // empty constructor 
    public Report() {
    
    }

    public void getDurationReport(){
    
        try {
             // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("select e1.driver_id, e1.first_name, e1.last_name, td1.train_id, DATEDIFF(IFNULL(td1.end_date, CURDATE()), td1.start_date) AS days_employed FROM drivers e1 JOIN train_driver_log td1 ON e1.driver_id = td1.driver_id");
            ResultSet rst = psmt.executeQuery();


            listDriverId.clear();
            fullName.clear();
            trainId.clear();
            daysEmployed.clear();

            while(rst.next()){
                listDriverId.add(rst.getInt(1));
                fullName.add(rst.getString(2) + " " + rst.getString(3));
                trainId.add(rst.getInt(4));
                daysEmployed.add(rst.getInt(5));
            }

            psmt.close();
            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());// TODO: handle exception
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        

    }
    
}

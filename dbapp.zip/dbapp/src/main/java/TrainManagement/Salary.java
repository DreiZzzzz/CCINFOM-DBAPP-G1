/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainManagement;

import java.sql.*; 
import java.util.*; 

/**
 *
 * @author Andrei
 */
public class Salary {
    
    public int salary_id;
    public int driver_id; 
    public double salary; 
    public String effective_from; 
    public String effective_to; 
    public String first_name;
    public String last_name; 
    
    // list
    public ArrayList<Integer> list_salary_id = new ArrayList<>();
    public ArrayList<Integer> list_driver_id = new ArrayList<>(); 
    public ArrayList<Double> list_salary = new ArrayList<>(); 
    public ArrayList<String> list_effective_from = new ArrayList<>(); 
    public ArrayList<String> list_effective_to = new ArrayList<>(); 
    public ArrayList<String> list_first_name = new ArrayList<>();
    public ArrayList<String> list_last_name = new ArrayList<>(); 
           
    
    // empty constructor 
    public Salary() {
    
    }
    
    public int delete_salaryID() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("DELETE FROM salary WHERE salary_id = ?");
            psmt.setInt(1, salary_id);

            psmt.executeUpdate(); 

            psmt.close();
            conn.close(); // close connection
            return 1; 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0; 
    }
    
    public void get_SalaryID() {
        int newSalaryID = -1; 
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT salary_id FROM salary");
            ResultSet rst = psmt.executeQuery();
            
            // clear list before adding values
            list_salary_id.clear(); 
            
            while(rst.next()) {
                salary_id = rst.getInt("salary_id");
                
                list_salary_id.add(salary_id); 
            }
            
            psmt = conn.prepareStatement("");
            psmt.setInt(1, newSalaryID);

            psmt.executeUpdate(); 

            psmt.close();
            conn.close(); // close connection
            
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }
    
    public int add_driverSalary() {
        int newSalaryID = -1; 
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(salary_id) + 1 AS newSalaryID FROM salary");
            ResultSet rst = psmt.executeQuery();
            
            while(rst.next()) {
                newSalaryID = rst.getInt("newSalaryID"); 
            }
            
            psmt = conn.prepareStatement("INSERT INTO salary(salary_id, driver_id, salary, effective_from, effective_to) VALUES(?, ?, ?, ?, ?)");
            psmt.setInt(1, newSalaryID);
            psmt.setInt(2, driver_id);
            psmt.setDouble(3, salary);
            psmt.setString(4, effective_from);
            psmt.setString(5, effective_to); 
            psmt.executeUpdate(); 

            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success 
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
        
        return 0; // if failure
    }
    
    public int update_salary() {
        int newSalaryID = -1; 
             try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT MAX(salary_id) + 1 AS newSalaryID FROM salary");
            ResultSet rst = psmt.executeQuery();
            
            
            while(rst.next()) {
                newSalaryID = rst.getInt("newSalaryID"); 
            }
            // set the null date to the given date 
            psmt = conn.prepareStatement("UPDATE salary s SET s.effective_to = ? WHERE s.driver_id = ? AND effective_to IS NULL"); 
            psmt.setDate(1, new java.sql.Date(System.currentTimeMillis()));
            psmt.setInt(2, driver_id); 
            psmt.executeUpdate(); 
            
            // create a new record for the updated salary 
            psmt = conn.prepareStatement("INSERT INTO salary(salary_id, driver_id, salary, effective_from, effective_to) VALUES(?, ?, ?, ?, ?)"); 
            psmt.setInt(1, newSalaryID);
            psmt.setInt(2, driver_id);
            psmt.setDouble(3, salary);
            psmt.setDate(4, new java.sql.Date(System.currentTimeMillis())); 
            psmt.setNull(5, Types.DATE); 
            psmt.executeUpdate(); 
            
            
            psmt.close();
            conn.close(); // close connection
            
            return 1; // if success
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
            return 0; 
    }
    
    
    public void display_salary() {
         try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // connect to database
            Connection conn = DriverManager.getConnection(MySql.localUrl, MySql.username, MySql.password);
            System.out.println("Connection successful!");
            
            PreparedStatement psmt = conn.prepareStatement("SELECT s.salary_id, s.salary, s.driver_id, d.last_name, d.first_name, s.effective_from, s.effective_to FROM salary s JOIN drivers d WHERE s.driver_id = d.driver_id");
            ResultSet rst = psmt.executeQuery();
            
            // clear list before adding values
            list_salary_id.clear(); 
            list_driver_id.clear();
            list_salary.clear();
            list_effective_from.clear();
            list_effective_to.clear();
            list_first_name.clear();
            list_last_name.clear();
            
            while(rst.next()) {
                salary_id = rst.getInt("s.salary_id");
                driver_id = rst.getInt("s.driver_id"); 
                salary = rst.getDouble("s.salary"); 
                effective_from = rst.getString("s.effective_from"); 
                effective_to = rst.getString("s.effective_to"); 
                first_name = rst.getString("d.first_name");
                last_name = rst.getString("d.last_name"); 
                
                list_salary_id.add(salary_id);
                list_driver_id.add(driver_id);
                list_salary.add(salary);
                list_effective_from.add(effective_from);
                list_effective_to.add(effective_to);
                list_first_name.add(first_name);
                list_last_name.add(last_name);
            }
            
            psmt.close();
            conn.close(); // close connection
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        }
    
    }
    
}
